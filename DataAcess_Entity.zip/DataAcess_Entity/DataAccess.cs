﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Linq.Expressions;

namespace DataAcess_Entity
{
    public class DataAccess<TEntity> where TEntity : class
    {
        private CMSDBEntities context = new CMSDBEntities();
        private GenericRepository<TEntity> repo;
      
        public GenericRepository<TEntity> Repository
        {
            get
            {

                if (this.repo == null)
                {
                    this.repo = new GenericRepository<TEntity>(context);
                }
                return repo;
            }
        }
       
        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}